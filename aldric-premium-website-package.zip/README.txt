
ALDRIC GROUP LTD PREMIUM WEBSITE PACKAGE

Included:
- Responsive Premium Homepage
- CSS Styling
- JavaScript File
- Privacy Policy Page
- Terms & Conditions Page
- Hero Banner Placeholder
- Organised Folder Structure

HOW TO USE:
1. Extract ZIP file
2. Open index.html in browser
3. Upload all files to hosting provider
4. Connect your domain
