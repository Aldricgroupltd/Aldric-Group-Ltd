
Aldric Group Ltd Website

Instructions:
1. Extract the ZIP file
2. Open index.html in your browser
3. Upload to Vercel or Netlify for hosting
